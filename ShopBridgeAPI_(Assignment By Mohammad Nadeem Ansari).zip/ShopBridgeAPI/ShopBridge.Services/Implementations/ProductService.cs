﻿using ShopBridge.Models;
using ShopBridge.Repositories.IRepositories;
using ShopBridge.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShopBridge.Services.Implementations
{
    public class ProductService : IProductService
    {
        public readonly IBaseRepository<Product> productRepository;
        public ProductService(IBaseRepository<Product> _productRepository)
        {
            this.productRepository = _productRepository;
        }

        public IEnumerable<Product> GetAllProduct()
        {
            var products = productRepository.GetAll();
            return products;
        }

        public Product GetProduct(int productId)
        {
            var products = productRepository.Get(x => x.Product_Id == productId);
            return products;
        }

        public int CreateProduct(Product product)
        {
            productRepository.Add(product);
            int result = productRepository.SaveChanges();
            return result;
        }

        public int UpdateProduct(Product product)
        {
            productRepository.Update(product);
            int result = productRepository.SaveChanges();
            return result;
        }

        public void Delete(Product product)
        {
            productRepository.Delete(product);
            productRepository.SaveChanges();
        }
    }
}
