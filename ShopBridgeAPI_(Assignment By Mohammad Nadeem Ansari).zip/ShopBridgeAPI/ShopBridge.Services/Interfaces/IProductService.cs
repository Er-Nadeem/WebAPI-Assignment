﻿using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShopBridge.Services.Interfaces
{
    public interface IProductService
    {
        IEnumerable<Product> GetAllProduct();
        Product GetProduct(int id);
        int CreateProduct(Product product);
        int UpdateProduct(Product product);
        void Delete(Product product);
    }
}
