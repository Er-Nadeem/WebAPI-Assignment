﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ShopBridge.Models;
using ShopBridge.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridgeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService productService;
        private readonly ILogger<ProductsController> logger;
        public ProductsController(IProductService _productService)
        {
            this.productService = _productService;
        }


        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProduct()
        {
            try
            {
                var products = productService.GetAllProduct();
                return Ok(products);
            }
            catch(Exception ex)
            {
                return NoContent();
            }
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            try
            {
                var product = productService.GetProduct(id);
                if (product != null)
                {
                    return Ok(product);                    
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                return NoContent();
            }
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, [FromBody] ProductViewModel product)
        {
            try
            {
                if (product != null && !string.IsNullOrEmpty(product.ProductName))
                {
                    var existingProduct = productService.GetProduct(id);
                    if (existingProduct != null)
                    {
                        existingProduct.Product_Name = product.ProductName;
                        existingProduct.Product_Description = product.ProductDescription;
                        existingProduct.Product_Price = product.ProductPrice;

                        productService.UpdateProduct(existingProduct);
                        return Ok();
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                return BadRequest();
            }
            catch (Exception ex)
            {
                return NoContent();
            }
        }


        [HttpPost]
        public async Task<ActionResult<Product>> PostProduct([FromBody] ProductViewModel product)
        {
            try
            {
                if (!string.IsNullOrEmpty(product.ProductName))
                {
                    Product _product = new Product();
                    _product.Product_Name = product.ProductName;
                    _product.Product_Description = product.ProductDescription;
                    _product.Product_Price = product.ProductPrice;
                    productService.CreateProduct(_product);
                    return Ok(_product);
                }
                return BadRequest();
            }
            catch (Exception ex)
            {
                return NoContent();
            }
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            try
            {
                var products = productService.GetProduct(id);
                if (products != null)
                {
                    productService.Delete(products);
                    return Ok();                   
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                return NoContent();
            }
        }
    }
}
