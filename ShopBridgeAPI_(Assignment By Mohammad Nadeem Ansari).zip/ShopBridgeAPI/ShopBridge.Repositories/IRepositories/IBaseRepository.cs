﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace ShopBridge.Repositories.IRepositories
{
    public interface IBaseRepository<T> where T : class
    {
        IEnumerable<T> GetAll(params Expression<Func<T, object>>[] navigationProperties);
        T Get(Expression<Func<T, bool>> where, params Expression<Func<T, object>>[] navigationProperties);
        void Add(T entity);
        void Update(T entity);
        void Delete(T entity);
        int SaveChanges();
    }
}
