﻿using Microsoft.EntityFrameworkCore;
using ShopBridge.Repositories.Infrastructure;
using ShopBridge.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace ShopBridge.Repositories.Repositories
{
    public class BaseRepository<T> : IBaseRepository<T> where T : class
    {
        internal Shopbridge_Context dbcontext;
        public BaseRepository(Shopbridge_Context _dbcontext)
        {
            this.dbcontext = _dbcontext;
        }        

        public IEnumerable<T> GetAll(params Expression<Func<T, object>>[] navigationProperties)
        {
            var query = dbcontext.Set<T>().AsQueryable();
            foreach (Expression<Func<T, object>> i in navigationProperties)
            {
                query = query.Include(i);
            }
            return query.ToList();
        }

        public T Get(Expression<Func<T, bool>> where, params Expression<Func<T, object>>[] navigationProperties)
        {
            var query = dbcontext.Set<T>().Where(where);
            foreach (Expression<Func<T, object>> i in navigationProperties)
            {
                query = query.Include(i);
            }
            return query.FirstOrDefault();
        }

        public virtual void Add(T entity) => dbcontext.Set<T>().Add(entity);

        public virtual void Update(T entity) => dbcontext.Entry(entity).State = EntityState.Modified;

        public virtual void Delete(T entity) => dbcontext.Remove(entity);

        public int SaveChanges() => dbcontext.SaveChanges();
    }
}
