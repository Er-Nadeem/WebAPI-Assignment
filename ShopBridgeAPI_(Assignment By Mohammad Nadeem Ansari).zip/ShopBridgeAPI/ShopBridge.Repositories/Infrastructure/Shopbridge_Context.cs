﻿using Microsoft.EntityFrameworkCore;
using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridge.Repositories.Infrastructure
{
    public class Shopbridge_Context: DbContext
    {
        public Shopbridge_Context(DbContextOptions<Shopbridge_Context> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
    }
}
