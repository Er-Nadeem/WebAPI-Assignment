using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ShopBridge.Models;
using ShopBridge.Repositories.Infrastructure;
using ShopBridge.Repositories.IRepositories;
using ShopBridge.Repositories.Repositories;
using ShopBridge.Services.Implementations;
using ShopBridge.Services.Interfaces;
using ShopBridgeAPI.Controllers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Xunit;

namespace ShopBridgeAPI.UnitTest
{
    public class ProductsControllerTest
    {
        ProductsController _controller;
        IProductService _service;
        IBaseRepository<Product> _repository;
        Shopbridge_Context _dbcontext;
        private readonly IConfiguration _configuration;
        private string _connectionString;


        public ProductsControllerTest()
        {           
            _configuration = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
            _connectionString = _configuration.GetConnectionString("Shopbridge_Context");

            var options = new DbContextOptionsBuilder<Shopbridge_Context>()
                             .UseSqlServer(new SqlConnection(_connectionString))
                             .Options;
            _dbcontext = new Shopbridge_Context(options);
            _repository = new BaseRepository<Product>(_dbcontext);
            _service = new ProductService(_repository);
            _controller = new ProductsController(_service);

        }

        [Fact]
        public async Task GetAllProductTest()
        {
            var result = await _controller.GetProduct();
            Assert.IsType<OkObjectResult>(result.Result);
            var list = result.Result as OkObjectResult;
            Assert.IsType<List<Product>>(list.Value);
        }

        [Theory]
        [InlineData(1, -1)]
        public async Task GetProductByIdTest(int id1, int id2)
        {
            int validId = id1;
            int invalidId = id2; 

            var notFoundResult = await _controller.GetProduct(invalidId);
            var okResult = await _controller.GetProduct(validId);

            Assert.IsType<NotFoundResult>(notFoundResult.Result);
            Assert.IsType<OkObjectResult>(okResult.Result);

            var item = okResult.Result as OkObjectResult;
            Assert.IsType<Product>(item.Value);

            var product = item.Value as Product;
            Assert.Equal(validId, product.Product_Id);
        }

        [Fact]
        public async Task AddProductTest()
        {
            var product = new ProductViewModel()
            {
                ProductName = "A.C.",
                ProductDescription = "Air Condition 5 Star",
                ProductPrice = 20000
            };
          
            var okResult = await _controller.PostProduct(product);
            Assert.IsType<OkObjectResult>(okResult.Result);

            var item = okResult.Result as OkObjectResult;
            Assert.IsType<Product>(item.Value);

            var productItem = item.Value as Product;
            Assert.Equal(product.ProductName, productItem.Product_Name);
            Assert.Equal(product.ProductDescription, productItem.Product_Description);
            Assert.Equal(product.ProductPrice, productItem.Product_Price);

            var incorrectProduct = new ProductViewModel()
            {
                ProductDescription = "Air Condition 5 Star",
                ProductPrice = 20000
            };

            _controller.ModelState.AddModelError("ProductName", "Product Name is a requried filed");
            var badResponse = await _controller.PostProduct(incorrectProduct);
            Assert.IsType<BadRequestResult>(badResponse.Result);
        }

        [Theory]
        [InlineData(2, -2)]
        public async Task EditProductByIdTest(int id1, int id2)
        {
            int validId = id1;
            int invalidId = id2;

            var product = new ProductViewModel()
            {
                ProductName = "A.C.",
                ProductDescription = "Air Condition 4 Star",
                ProductPrice = 21000
            };

            var notFoundResult = await _controller.PutProduct(invalidId, product);
            Assert.IsType<NotFoundResult>(notFoundResult);

            var okResult = await _controller.PutProduct(validId, product);
            Assert.IsType<OkResult>(okResult);            

            var incorrectProduct = new ProductViewModel()
            {
                ProductDescription = "Air Condition 3 Star",
                ProductPrice = 19000
            };

            _controller.ModelState.AddModelError("ProductName", "Product Name is a requried filed");
            var badResponse = await _controller.PutProduct(validId, incorrectProduct);
            Assert.IsType<BadRequestResult>(badResponse);
        }

        [Theory]
        [InlineData(1, -1)]
        public async Task DeleteProductByIdTest(int id1, int id2)
        {
            int validId = id1;
            int invalidId = id2;

            var notFoundResult = await _controller.DeleteProduct(invalidId);
            Assert.IsType<NotFoundResult>(notFoundResult);

            var okResult = await _controller.DeleteProduct(validId);
            Assert.IsType<OkResult>(okResult);
        }
    }
}
